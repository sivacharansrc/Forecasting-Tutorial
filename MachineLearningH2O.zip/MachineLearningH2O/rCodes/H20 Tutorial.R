### PREPEARING ENVIRONMENT
rm(list = ls())
options(scipen = 999)
library(data.table)
library(ggplot2)
library(dummies)
library(h2o)
#library(dplyr) 

###### READING DATA ##### str(train)

train <- fread("./source/train.csv", header = T, stringsAsFactors = T)
test <- fread("./source/test.csv", header = T, stringsAsFactors = T)

#first prediction using mean
sub_mean <- data.frame(User_ID = test$User_ID, Product_ID = test$Product_ID, 
                         Purchase = mean(train$Purchase))

#write.csv(sub_mean, file = "first_sub.csv", row.names = F)

# View(head(train)) View(head(test)) View(head(sub_mean))
# summary(train) summary(train)

#### COMBINING DATA SET

test[, Purchase := mean(train$Purchase)]
df <- rbind(train, test)


### Data Exploration #####

prop.table(table(df$Gender))
prop.table(table(df$Occupation))

### BIVARIABLE ANALYSIS ####

ggplot(df, aes(Age, fill = Gender)) + geom_bar()

CrossTable(df$Occupation, df$City_Category)
table(df$Occupation, df$City_Category)

df[, Product_Category_2_NA := ifelse(is.na(Product_Category_2),0,1)][,Product_Category_3_NA := ifelse(is.na(Product_Category_3),0,1)]

### IMPUTING THE MISSING NUMBERS WITH AN ARBITRARY NUMBER View(head(df))

df[is.na(Product_Category_2),Product_Category_2 := -999][is.na(Product_Category_3),Product_Category_3 := -999]


### BEFORE FEATURE ENGINEERING, LET US REVALUE VARIABLE LEVELS

levels(df$Age)[levels(df$Age) == "0-17"] <- 0
levels(df$Age)[levels(df$Age) == "18-25"] <- 1
levels(df$Age)[levels(df$Age) == "26-35"] <- 2
levels(df$Age)[levels(df$Age) == "36-45"] <- 3
levels(df$Age)[levels(df$Age) == "46-50"] <- 4
levels(df$Age)[levels(df$Age) == "51-55"] <- 5
levels(df$Age)[levels(df$Age) == "55+"] <- 6

levels(df$Stay_In_Current_City_Years)[levels(df$Stay_In_Current_City_Years) == "4+"] <- 4

### CONVERT AGE TO NUMERIC

df$Age <- as.numeric(df$Age)

df$Gender <- as.numeric(df$Gender)-1

#Count of Product Purchase and User Purchase

df[,User_Count := .N, User_ID][,Product_Count := .N, Product_ID]

#View(head(df))

#Mean Purchase of Product & User
df[, Mean_Purchase_Product := mean(Purchase), by = Product_ID][, Mean_Purchase_User := mean(Purchase), by = User_ID]

# Hot Encoding

head(df)

df <- dummy.data.frame(df, names = c("City_Category"), sep = "_")

# Checking Classes to make sure all are integer or numeric

sapply(df, class)
df$Stay_In_Current_City_Years <- as.numeric(df$Stay_In_Current_City_Years)






